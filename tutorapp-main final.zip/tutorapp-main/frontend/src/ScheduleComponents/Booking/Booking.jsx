import React from 'react'
import Nav from "../ScheduleNav/ScheduleNav";

function Booking() {
  return (
    <div>
      <Nav/>
      <h1>Booking</h1>
    </div>
  )
}

export default Booking