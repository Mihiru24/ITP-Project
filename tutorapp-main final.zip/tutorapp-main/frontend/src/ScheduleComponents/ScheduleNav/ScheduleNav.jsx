import React from 'react'

function Nav() {
  return (
    <div>
      <h1>This is a nav bar</h1>
    </div>
  )
}

export default Nav